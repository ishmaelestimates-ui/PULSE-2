"""
Episode model.

An Episode represents a single podcast episode: its transcript, its
duration, and the raw analysis payload returned by Gemini. Individual
editorial decisions derived from that analysis live in EditorialReview
rows (see app/models/editorial_review.py), linked via `episode_id`.
"""
from datetime import datetime, timezone

from sqlalchemy import DateTime, Float, Integer, String, Text
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database import Base


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


class Episode(Base):
    __tablename__ = "episodes"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    title: Mapped[str] = mapped_column(String(500), nullable=False)
    duration: Mapped[float | None] = mapped_column(Float, nullable=True)
    transcript: Mapped[str] = mapped_column(Text, nullable=False)

    # Raw analysis payload returned by Gemini, kept alongside the
    # normalized EditorialReview rows for auditability/debugging.
    analysis: Mapped[dict | None] = mapped_column(JSONB, nullable=True)

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_utcnow, nullable=False
    )

    reviews: Mapped[list["EditorialReview"]] = relationship(
        "EditorialReview",
        back_populates="episode",
        cascade="all, delete-orphan",
        order_by="EditorialReview.id",
    )

    def __repr__(self) -> str:  # pragma: no cover - debugging helper
        return f"<Episode id={self.id} title={self.title!r}>"
