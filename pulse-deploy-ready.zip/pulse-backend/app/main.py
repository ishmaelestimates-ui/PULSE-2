"""
PULSE backend — FastAPI application entrypoint.

Wires up the episode, analysis, and review routers, and exposes a health
check for container orchestration / load balancer probes.
"""
import logging

from fastapi import FastAPI
from fastapi.exception_handlers import http_exception_handler
from fastapi.exceptions import HTTPException
from fastapi.middleware.cors import CORSMiddleware

from app.api import analysis, episodes, reviews
from app.config import get_settings

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

settings = get_settings()

app = FastAPI(
    title="PULSE",
    description="Podcast production and distribution system backend.",
    version="0.1.0",
)

# Permissive CORS for MVP/local development. Tighten allow_origins before
# deploying to production.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(episodes.router)
app.include_router(analysis.router)
app.include_router(reviews.router)


@app.exception_handler(HTTPException)
async def log_http_exceptions(request, exc: HTTPException):
    """Log HTTPExceptions before delegating to the default handler, so
    4xx/5xx responses are visible in server logs."""
    logger.warning("HTTPException %s at %s: %s", exc.status_code, request.url, exc.detail)
    return await http_exception_handler(request, exc)


@app.get("/health", tags=["health"])
def health_check():
    return {"status": "ok", "environment": settings.environment}


@app.get("/", tags=["health"])
def root():
    return {"service": "PULSE backend", "docs": "/docs"}
