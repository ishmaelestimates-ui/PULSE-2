"""
Application configuration.

Settings are loaded from environment variables (optionally via a .env file
in the project root). See .env.example for the full list of variables.
"""
from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    # Database
    database_url: str = "postgresql://user:pass@localhost:5432/pulse"

    # Gemini
    gemini_api_key: str = "your-key-here"
    gemini_model: str = "gemini-1.5-pro"

    # App
    secret_key: str = "your-secret-key"
    environment: str = "development"

    # Export
    resolve_frame_rate: float = 24.0

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )


@lru_cache
def get_settings() -> Settings:
    """Cached settings accessor so we don't re-parse the environment on
    every request."""
    return Settings()
