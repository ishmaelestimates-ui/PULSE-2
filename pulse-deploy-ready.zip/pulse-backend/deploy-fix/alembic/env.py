"""
Alembic environment file. Pulls the database URL from application
settings (i.e. the DATABASE_URL environment variable) rather than a
hardcoded value in alembic.ini, and points autogenerate at the app's
declarative Base so `alembic revision --autogenerate` picks up model
changes.
"""
from logging.config import fileConfig

from alembic import context
from sqlalchemy import engine_from_config, pool

from app.config import get_settings
from app.database import Base
from app.models import (  # noqa: F401 - ensure models are registered
    ActivityLogEntry,
    BrandSettings,
    BudgetItem,
    CampaignPack,
    ColorGrade,
    CompetitorBenchmark,
    Coverage,
    CulturalFootprintItem,
    EditorialReview,
    Embargo,
    Episode,
    FameScoreSnapshot,
    FestivalMatch,
    FilmAct,
    Invite,
    JournalistLead,
    MagicLinkToken,
    MediaFile,
    Mention,
    ProjectMilestone,
    RedditComment,
    RedditKarma,
    RedditPost,
    ScheduledPost,
    PressKit,
    TerritoryRelease,
    TrailerCut,
    User,
)

config = context.config

if config.config_file_name is not None:
    fileConfig(config.config_file_name)

settings = get_settings()
config.set_main_option("sqlalchemy.url", settings.database_url)

target_metadata = Base.metadata


def run_migrations_offline() -> None:
    url = config.get_main_option("sqlalchemy.url")
    context.configure(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
    )

    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    connectable = engine_from_config(
        config.get_section(config.config_ini_section, {}),
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )

    with connectable.connect() as connection:
        context.configure(connection=connection, target_metadata=target_metadata)

        with context.begin_transaction():
            context.run_migrations()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
